<nav>
    <ul>
        <li><a href="../pages/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="../pages/profile.php"><i class="fas fa-user"></i> Profile</a></li>
        <li><a href="../pages/room_booking.php"><i class="fas fa-calendar-check"></i> Room Booking</a></li>
        <li><a href="../pages/class_schedule.php"><i class="fas fa-chalkboard-teacher"></i> Class Schedule</a></li>
        <li><a href="../pages/maintenance.php"><i class="fas fa-tools"></i> Maintenance</a></li>
        <li><a href="../pages/announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a></li>
        <li><a href="../backend/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</nav>
