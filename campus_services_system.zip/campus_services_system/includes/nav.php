<nav>
    <ul>
        <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
        <li><a href="room_booking.php"><i class="fas fa-calendar-check"></i> Room Booking</a></li>
        <li><a href="class_schedule.php"><i class="fas fa-chalkboard-teacher"></i> Class Schedule</a></li>
        <li><a href="maintenance.php"><i class="fas fa-tools"></i> Maintenance</a></li>
        <li><a href="announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</nav>
