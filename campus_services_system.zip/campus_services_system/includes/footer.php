<!-- Footer -->
<footer>
    <p>&copy; 2025 Campus Management System. All rights reserved.</p>
</footer>
